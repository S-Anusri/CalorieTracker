import java.util.*;
public class LunchDinner extends Food{
    private FItems items; 
    private String[] foods;
    private Double[] fvalues;

    LunchDinner(){
        foods = new String[3];
        foods[0] = "Roti";
        foods[1] = "Curry";
        foods[2] = "Pulao";
        
        fvalues = new Double[3];
        items = new FItems();

        fvalues[0] = 0.4*(items.getVal9());  //Flour
        fvalues[1] = 2.2*(items.getVal1()) +   0.05*(items.getVal6()) + 0.1*(items.getVal10());    //Veg + Oil + Spices
        fvalues[2] = 2.5*(items.getVal11()) +   1*(items.getVal1()) + 0.02*(items.getVal6());      //Rice + Vegetables + Oil                                                               //
    }

    public Double fooddetails(int[] qty){
        Double[] total = new Double[3];
        Double sum = 0.0;
        total[0] = qty[0]*fvalues[0];
        total[1] = qty[1]*fvalues[1];
        total[2] = qty[2]*fvalues[2];
        sum = total[0] + total[1] + total[2];
        return sum;
    }
}