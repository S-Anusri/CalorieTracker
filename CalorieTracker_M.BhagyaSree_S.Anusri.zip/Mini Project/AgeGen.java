import javax.lang.model.util.ElementScanner14;

public class AgeGen{
    private int age;
    private char gen;  

    AgeGen(int a, char c){
        this.age = a;
        this.gen = c;
    }

    public int getAge(int a){
        this.age = a;
        return a;
    }

    public char getGender(char c){
        this.gen = c;
        return gen;
    }

    public String getDetails(double cals){
        String s;
        if(this.gen == 'M'){
            if((this.age >= 1 && this.age <= 3) && (cals >= 1000 && cals <= 1400))
            {
                s = "You are a fit and active baby!";
            }
            else if((this.age >= 4 && this.age <= 8) && (cals >= 1600 && cals <= 2000))
            {
                s = "You are a fit and active child!";
            }
            else if((this.age >= 9 && this.age <= 13) && (cals >= 2000 && cals <= 2600))
            {
                s = "You are a fit and active child!";
            }
            else if((this.age >= 14 && this.age <= 18) && (cals >= 2800 && cals <= 3200))
            { 
                s = "You are a fit and active teen!";
            }
            else if((this.age >= 19 && this.age <= 30) && (cals >= 2800 && cals <= 3000))
            {
                s = "You are a fit and active adult!";
            }
            else if((this.age >= 31 && this.age <= 50) && (cals >= 2800 && cals <= 3000))
            {
                s = "You are a fit and active adult!";
            }
            else if((this.age >= 51 && this.age <= 115) && (cals >= 2400 && cals <= 2800))
            {
                s = "You are a fit and active adult!";
            }
            else
            {
                s = "You are not fit and active!";
            }
        }
        else{
            if((this.age >= 1 && this.age <= 3) && (cals >= 1000 && cals <= 1400))
            {
                s = "You are a fit and active baby!";
            }
            else if((this.age >= 4 && this.age <= 8) && (cals >= 1400 && cals <= 1800))
            {
                s = "You are a fit and active child!";
            }
            else if((this.age >= 9 && this.age <= 13) && (cals >= 1800 && cals <= 2200))
            {
                s = "You are a fit and active child!";
            }
            else if((this.age >= 14 && this.age <= 18) && (cals >= 2000 && cals <= 2400))
            {
                s = "You are a fit and active teen!";
            }
            else if((this.age >= 19 && this.age <= 30) && (cals >= 2200 && cals <= 2400))
            {
                s = "You are a fit and active adult!";
            }
            else if((this.age >= 31 && this.age <= 50) && (cals >= 2000 && cals <= 2200))
            {
                s = "You are a fit and active adult!";
            }
            else if((this.age >= 51 && this.age <= 115) && (cals >= 2000 && cals <= 2200))
            {
                s = "You are a fit and active adult!";
            }
            else
            {
                s = "You are not fit and active!";
            }
        }
        return s;
    }
}