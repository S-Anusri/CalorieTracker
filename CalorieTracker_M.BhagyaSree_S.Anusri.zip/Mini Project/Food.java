public abstract class Food{
    public abstract Double fooddetails(int[] qty);
} 