import java.util.*;
public class Drinks extends Food{
    private FItems items;
    private String[] foods;
    private Double[] fvalues;

    Drinks(){
        foods = new String[3]; 
        foods[0] = "Milkshake";
        foods[1] = "Green Tea";
        foods[2] = "Black Coffee";
        
        fvalues = new Double[3];
        items = new FItems();
        
        fvalues[0] = 2.5*(items.getVal0()) + 0.08*(items.getVal5()) + 1*(items.getVal12());  //Milk + Sugar + Fruits
        fvalues[1] = 2*(items.getVal2());    //Green Tea Bag
        fvalues[2] = 2*(items.getVal3());      //Coffee                                                             
    }

    public Double fooddetails(int[] qty){
        Double[] total = new Double[3];
        Double sum = 0.0;
        total[0] = qty[0]*fvalues[0];
        total[1] = qty[1]*fvalues[1];
        total[2] = qty[2]*fvalues[2];
        sum = total[0] + total[1] + total[2];
        return sum;
    }
}