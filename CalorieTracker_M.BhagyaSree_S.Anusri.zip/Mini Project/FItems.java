public class FItems{ 
    private String[] items;
    private Double[] val;
    FItems(){
        items = new String[13];
        items[0] = "Milk";
        items[1] = "Vegetables";
        items[2] = "Teabag";
        items[3] = "BCoffee";
        items[4] = "Cereal";
        items[5] = "Sugar";
        items[6] = "Oil";
        items[7] = "Chutney";
        items[8] = "Dosa Batter";
        items[9] = "Flour";
        items[10] = "Spices";
        items[11] = "Rice";
        items[12] = "Fruits";

        val = new Double[13];
        val[0] = 42.0;  //100 ml
        val[1] = 65.0; //100 gms
        val[2] = 1.0; //100 ml
        val[3] = 2.0; //100 ml
        val[4] = 379.0; //100 gms
        val[5] = 387.0; //100 gms
        val[6] = 884.0; //100 ml
        val[7] = 78.0; //100 gms
        val[8] = 143.0; //100 gms
        val[9] = 329.0; //100 gms
        val[10] = 251.0; //100 gms
        val[11] = 130.0;  //100 gms
        val[12] =  52.0; //100 gms
    }
    //Methods
    public Double getVal0(){
        return val[0];
    }
    public Double getVal1(){
        return val[1];
    }
    public Double getVal2(){
        return val[2];
    }
    public Double getVal3(){
        return val[3];
    }
    public Double getVal4(){
        return val[4];
    }
    public Double getVal5(){
        return val[5];
    }
    public Double getVal6(){
        return val[6];
    }
    public Double getVal7(){
        return val[7];
    }
    public Double getVal8(){
        return val[8];
    }
    public Double getVal9(){
        return val[9];
    }
    public Double getVal10(){
        return val[10];
    }
    public Double getVal11(){
        return val[11];
    }

    public Double getVal12(){
        return val[12];
    }
}