import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;

/**
 * CalorieCal
 */
public class CalorieCal extends Canvas implements ActionListener{

    JFrame f;
    JLabel a, g, l, l1, l2, l3, l4, l5, l6;
    JTextField ag, ge, c,d,p;
    JTextField r,v,pu;
    JTextField ms,gt,bc;
    JTextField dr,dv,dpu;
    JTextField t1,t2,t3,t4,t5;
    JButton b;
    

    CalorieCal()
    {
        f = new JFrame("Calorie Tracker");
        a = new JLabel("Age: ");
        a.setBounds(10, 10, 100, 20);
        ag = new JTextField();
        ag.setBounds(40, 14, 30, 18);
        g = new JLabel("Gender: ");
        g.setBounds(90, 10, 100, 20);
        ge = new JTextField();
        ge.setBounds(140, 14, 40, 18);
        l = new JLabel("Enter quantities for each of the food items consumed under the following categories: ");
        l.setForeground(Color.red);
        l.setBounds(10, 36, 600, 20);

        l1 = new JLabel("BREAKFAST");
        l1.setForeground(Color.blue);
        l1.setBounds(10, 50,100,40);
        l1.setFont(new Font("", Font.BOLD, 16));


        JLabel cereal = new JLabel("Cereal");
        cereal.setBounds(10, 85, 80, 21);
        cereal.setBackground(Color.lightGray);
        cereal.setFont(new Font("SansSerif", Font.BOLD, 15));
        cereal.setOpaque(true);
        JLabel dosa = new JLabel("Dosa");
        dosa.setBounds(10, 105, 80, 21);
        dosa.setBackground(Color.lightGray);
        dosa.setFont(new Font("SansSerif", Font.BOLD, 15));
        dosa.setOpaque(true);
        JLabel poori = new JLabel("Poori");
        poori.setBounds(10, 124, 80, 21);
        poori.setBackground(Color.lightGray);
        poori.setFont(new Font("SansSerif", Font.BOLD, 15));
        poori.setOpaque(true);

        c = new JTextField();
        c.setBounds(90, 85, 30, 20);
        d = new JTextField();
        d.setBounds(90, 105, 30, 20);
        p = new JTextField();
        p.setBounds(90, 125, 30, 20);

        JLabel label1 = new JLabel("Total:");
        label1.setBounds(10,145,100,30);
        t1 = new JTextField();
        t1.setBounds(10, 175, 100, 30);
        t1.setEditable(false);

        l2 = new JLabel("LUNCH");
        l2.setForeground(Color.blue);
        l2.setBounds(140, 50,100,40);
        l2.setFont(new Font("", Font.BOLD, 16));

        JLabel roti = new JLabel("Roti");
        roti.setBounds(140, 85, 80, 21);
        roti.setBackground(Color.lightGray);
        roti.setFont(new Font("SansSerif", Font.BOLD, 15));
        roti.setOpaque(true);
        JLabel vegcurry = new JLabel("Veg. Curry");
        vegcurry.setBounds(140, 105, 80, 21);
        vegcurry.setBackground(Color.lightGray);
        vegcurry.setFont(new Font("SansSerif", Font.BOLD, 15));
        vegcurry.setOpaque(true);
        JLabel pulao = new JLabel("Pulao");
        pulao.setBounds(140, 124, 80, 21);
        pulao.setBackground(Color.lightGray);
        pulao.setFont(new Font("SansSerif", Font.BOLD, 15));
        pulao.setOpaque(true);

        r = new JTextField();
        r.setBounds(220, 85, 30, 20);
        v = new JTextField();
        v.setBounds(220, 105, 30, 20);
        pu = new JTextField();
        pu.setBounds(220, 125, 30, 20);

        JLabel label2 = new JLabel("Total:");
        label2.setBounds(140,145,100,30);
        t2 = new JTextField();
        t2.setBounds(140, 175, 100, 30);
        t2.setEditable(false);

        l3 = new JLabel("DRINKS");
        l3.setForeground(Color.blue);
        l3.setBounds(280, 50,100,40);
        l3.setFont(new Font("", Font.BOLD, 16));

        JLabel milkshake = new JLabel("Milk Shake");
        milkshake.setBounds(280, 85, 100, 21);
        milkshake.setBackground(Color.lightGray);
        milkshake.setFont(new Font("SansSerif", Font.BOLD, 15));
        milkshake.setOpaque(true);
        JLabel greentea = new JLabel("Green Tea");
        greentea.setBounds(280, 105, 100, 21);
        greentea.setBackground(Color.lightGray);
        greentea.setFont(new Font("SansSerif", Font.BOLD, 15));
        greentea.setOpaque(true);
        JLabel coffee = new JLabel("Black Coffee");
        coffee.setBounds(280, 124, 100, 21);
        coffee.setBackground(Color.lightGray);
        coffee.setFont(new Font("SansSerif", Font.BOLD, 15));
        coffee.setOpaque(true);

        ms = new JTextField();
        ms.setBounds(380, 85, 30, 20);
        gt = new JTextField();
        gt.setBounds(380, 105, 30, 20);
        bc = new JTextField();
        bc.setBounds(380, 125, 30, 20);

        JLabel label3 = new JLabel("Total:");
        label3.setBounds(280,145,100,30);
        t3 = new JTextField();
        t3.setBounds(280, 175, 100, 30);
        t3.setEditable(false);

        l4 = new JLabel("DINNER");
        l4.setForeground(Color.blue);
        l4.setBounds(430,50,100,40);
        l4.setFont(new Font("", Font.BOLD, 16));

        JLabel ro = new JLabel("Roti");
        ro.setBounds(430, 85, 80, 21);
        ro.setBackground(Color.lightGray);
        ro.setFont(new Font("SansSerif", Font.BOLD, 15));
        ro.setOpaque(true);
        JLabel veg = new JLabel("Veg. Curry");
        veg.setBounds(430, 105, 80, 21);
        veg.setBackground(Color.lightGray);
        veg.setFont(new Font("SansSerif", Font.BOLD, 15));
        veg.setOpaque(true);
        JLabel pul = new JLabel("Pulao");
        pul.setBounds(430, 124, 80, 21);
        pul.setBackground(Color.lightGray);
        pul.setFont(new Font("SansSerif", Font.BOLD, 15));
        pul.setOpaque(true);

        dr = new JTextField();
        dr.setBounds(511, 85, 30, 20);
        dv = new JTextField();
        dv.setBounds(511, 105, 30, 20);
        dpu = new JTextField();
        dpu.setBounds(511, 125, 30, 20);

        JLabel label4 = new JLabel("Total:");
        label4.setBounds(430,145,100,30);
        t4 = new JTextField();
        t4.setBounds(430, 175, 100, 30);
        t4.setEditable(false);

        b = new JButton("SUBMIT");
        b.setBounds(200, 235,100, 40);

        l5 = new JLabel("Total Calories:");
        l5.setBounds(120, 290, 200, 40);
        l5.setForeground(Color.blue);
        l5.setFont(new Font("", Font.BOLD, 16));
        t5 = new JTextField();
        t5.setBounds(250, 295, 100, 30);
        t5.setEditable(false);

        l6 = new JLabel("");
        l6.setBounds(120, 320, 280, 45);

        b.addActionListener(this);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f.add(a); f.add(ag); f.add(g); f.add(ge); f.add(l);
        f.add(l1); f.add(cereal);f.add(dosa);f.add(poori);f.add(c);f.add(d);f.add(p);
        f.add(l2); f.add(roti);f.add(vegcurry);f.add(pulao);f.add(r);f.add(v);f.add(pu);
        f.add(l3); f.add(milkshake);f.add(greentea);f.add(coffee);f.add(ms);f.add(gt);f.add(bc);
        f.add(l4); f.add(ro);f.add(veg);f.add(pul);f.add(dr);f.add(dv);f.add(dpu);
        f.add(label1);f.add(label2);f.add(label3);f.add(label4);
        f.add(t1);f.add(t2);f.add(t3);f.add(t4);
        f.add(b);f.add(l5);f.add(t5); f.add(l6);
        f.setLayout(null);
        f.setSize(600,500);
        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        int[] bfqty = new int[3];
        int[] lunchqty= new int[3];
        int[] drinksqty= new int[3];
        int[] dinnerqty= new int[3];
        
        int Age;
        char Gender;
        if(ag.getText().equals(""))
        {
            Age = 1;
        }
        else
        {
            Age = Integer.parseInt(ag.getText());
        }
        if(Age < 1)
        {
            Age = 1;
        }
        if(Age > 115)
        {
            Age = 115;
        }
        if(ge.getText().equals(""))
        {
            Gender = 'M';
        }
        else
        {
            Gender = ge.getText().charAt(0);
        }
        AgeGen details = new AgeGen(Age, Gender);
        Breakfast bf = new Breakfast();
        LunchDinner lunch = new LunchDinner();
        Drinks drinks = new Drinks();
        LunchDinner dinner = new LunchDinner(); 
    
        if(c.getText().equals(""))
        {
            bfqty[0] = 0;
        }
        else
        {
            bfqty[0] = Integer.parseInt(c.getText());
        }

        if(d.getText().equals(""))
        {
            bfqty[1] = 0;
        }
        else
        {
            bfqty[1] = Integer.parseInt(d.getText());
        }

        if(p.getText().equals(""))
        {
            bfqty[2] = 0;
        }
        else
        {
            bfqty[2] = Integer.parseInt(p.getText());
        }

        if(r.getText().equals(""))
        {
            lunchqty[0] = 0;
        }
        else
        {
            lunchqty[0] = Integer.parseInt(r.getText());
        }

        if(v.getText().equals(""))
        {
            lunchqty[1] = 0;
        }
        else
        {
            lunchqty[1] = Integer.parseInt(v.getText());
        }

        if(pu.getText().equals(""))
        {
            lunchqty[2] = 0;
        }
        else
        {
            lunchqty[2] = Integer.parseInt(pu.getText());
        }

        if(ms.getText().equals(""))
        {
            drinksqty[0] = 0;
        }
        else
        {
            drinksqty[0] = Integer.parseInt(ms.getText());
        
        }

        if(gt.getText().equals(""))
        {
            drinksqty[1] = 0;
        }
        else
        {
            drinksqty[1] = Integer.parseInt(gt.getText());
        
        }

        if(bc.getText().equals(""))
        {
            drinksqty[2] = 0;
        }
        else
        {
            drinksqty[2] = Integer.parseInt(bc.getText());
        
        }

        if(dr.getText().equals(""))
        {
            dinnerqty[0] = 0;
        }
        else
        {
            dinnerqty[0] = Integer.parseInt(dr.getText());
        
        }

        if(dv.getText().equals(""))
        {
            dinnerqty[1] = 0;
        }
        else
        {
            dinnerqty[1] = Integer.parseInt(dv.getText());
        }

        if(dpu.getText().equals(""))
        {
            dinnerqty[2] = 0;
        }
        else
        {
            dinnerqty[2] = Integer.parseInt(dpu.getText());
        }

        for(int i = 0; i < 3; i++)
        {
            if(bfqty[i] < 0)
            {
                bfqty[i] = 0;
            }
        }

        for(int i = 0; i < 3; i++)
        {
            if(lunchqty[i] < 0)
            {
                lunchqty[i] = 0;
            }
        }
        
        for(int i = 0; i < 3; i++)
        {
            if(dinnerqty[i] < 0)
            {
                dinnerqty[i] = 0;
            }
        }
        
        for(int i = 0; i < 3; i++)
        {
            if(drinksqty[i] < 0)
            {
                drinksqty[i] = 0;
            }
        }
        String bftotal = String.valueOf(String.format("%.2f",bf.fooddetails(bfqty) ));
        String ltotal = String.valueOf(String.format("%.2f",lunch.fooddetails(lunchqty) ));
        String drftotal = String.valueOf(String.format("%.2f",drinks.fooddetails(drinksqty)));
        String dtotal = String.valueOf(String.format("%.2f",dinner.fooddetails(dinnerqty)));
       
        double total = (bf.fooddetails(bfqty)+lunch.fooddetails(lunchqty)+drinks.fooddetails(drinksqty)+dinner.fooddetails(dinnerqty));
        String result = String.valueOf(String.format("%.4f",total));

        t1.setText(bftotal);
        t2.setText(ltotal);
        t3.setText(drftotal);
        t4.setText(dtotal);

        t5.setText(result);
        String str = details.getDetails(total);
        l6.setText(str);
    }
    
    public static void main(String[] args) {
        new CalorieCal();
    }
    
}