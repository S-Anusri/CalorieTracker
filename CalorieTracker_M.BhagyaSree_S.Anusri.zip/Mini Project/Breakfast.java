import java.util.*;
public class Breakfast extends Food{
    private FItems items;
    private String[] foods;
    private Double[] fvalues;
 
    Breakfast(){
        foods = new String[3];
        foods[0] = "Cereal";
        foods[1] = "Dosa";
        foods[2] = "Poori";
        
        fvalues = new Double[3];
        items = new FItems();
        
        fvalues[0] = 0.5*(items.getVal4()) + 1*(items.getVal0());  //Cereal + Milk
        fvalues[1] = 1*(items.getVal8()) +   1*(items.getVal7()) + 0.02*(items.getVal6());    //Batter + Chutney + Oil
        fvalues[2] = 1*(items.getVal8()) +   1*(items.getVal7()) + 0.093*(items.getVal6());      //Batter + Chutney + Oil                                                                  //
    }

    public Double fooddetails(int[] qty){
        Double[] total = new Double[3];
        Double sum = 0.0;
        total[0] = qty[0]*fvalues[0];
        total[1] = qty[1]*fvalues[1];
        total[2] = qty[2]*fvalues[2];
        sum = total[0] + total[1] + total[2];
        return sum;
    }
}